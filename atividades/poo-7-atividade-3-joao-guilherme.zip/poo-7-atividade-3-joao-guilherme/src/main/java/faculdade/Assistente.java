package faculdade;

import java.util.Scanner;

public class Assistente {
    private String nome;
    private String setor;
    private String atribuicao;

    @Override
    public String toString(){
        return "Assistente{" +
                ", nome='" + nome + '\'' +
                ", Setor='" + setor + '\'' +
                ", Atribuição='" + atribuicao + '\'' +
                '}';
    }

    public void dados(){ System.out.println(this); }

    public static Assistente criar(){
        var objetoAssistente = new Assistente();
        var scanner = new Scanner(System.in);

        System.out.println("Nome: ");
        objetoAssistente.nome = scanner.nextLine();

        System.out.println("Setor: ");
        objetoAssistente.setor = scanner.nextLine();

        System.out.println("Atribuição: ");
        objetoAssistente.atribuicao = scanner.nextLine();

        System.out.println(objetoAssistente.nome + "cadastrado");
        return objetoAssistente;
    }
}
