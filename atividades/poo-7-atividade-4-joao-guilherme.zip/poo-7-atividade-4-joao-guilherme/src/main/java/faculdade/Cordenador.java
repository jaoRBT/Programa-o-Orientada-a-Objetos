package faculdade;

import java.util.Scanner;

public class Cordenador {
    private String nome;
    private String curso;
    private String turno;

    @Override
    public String toString() {
        return "Docente{" +
                "nome='" + nome + '\'' +
                ", curso='" + curso + '\'' +
                ", turno='" + turno + '\'' +
                '}';
    }

    public void imprimirDados(){
        System.out.println(this);
    }

    public static Cordenador criar(){
        var objetoDocente = new Cordenador();
        var scanner =  new Scanner(System.in);

        System.out.println("Nome:");
        objetoDocente.nome = scanner.nextLine();

        System.out.println("Curso:");
        objetoDocente.curso = scanner.nextLine();

        System.out.println("Turno:");
        objetoDocente.turno = scanner.nextLine();

        System.out.println(objetoDocente.nome + " cadastrado!");
        return objetoDocente;
    }
}
