package faculdade;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Programa {
    public static void main(String[] args) {
        System.out.println("“Cadastro de Técnicos");
        ca
    }
     private void cadastroTecnico(){
        List<Tecnico> tecnicos = new ArrayList<>();
         for (int i = 0; i < 3; i++) tecnicos.add(Tecnico.criar());

         var scanner = new Scanner(System.in);
         do {
             tecnicos.add(Tecnico.criar());
         }while (scanner.nextLine().equals("s"));

         tecnicos.forEach(Tecnico::dados);
    }
}
