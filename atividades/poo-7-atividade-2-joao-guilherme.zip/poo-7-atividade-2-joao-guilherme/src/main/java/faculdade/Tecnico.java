package faculdade;

import java.util.Scanner;

public class Tecnico {
    private String nome;
    private String departamento;
    private String especialidade;


    public void  dados(){ System.out.println(nome + " - " + departamento + " - " + especialidade);}

    public static Tecnico criar(){
        var objetoTecico = new  Tecnico();
        var scanner = new Scanner(System.in);

        System.out.println("Nome: ");
        objetoTecico.nome = scanner.nextLine();

        System.out.println("Departamento: ");
        objetoTecico.departamento = scanner.nextLine();

        System.out.println("Especialidade: ");
        objetoTecico.especialidade = scanner.nextLine();

        System.out.println(objetoTecico.nome + "cadastro");
        return objetoTecico;
    }
}


