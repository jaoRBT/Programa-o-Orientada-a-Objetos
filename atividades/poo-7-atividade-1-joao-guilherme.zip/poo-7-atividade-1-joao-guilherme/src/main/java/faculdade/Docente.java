package faculdade;

import java.util.Scanner;

public class Docente {
    private String nome;
    private String formacao;
    private String cidade;

    public void inprimirdados(){
        System.out.println(nome + " - " + formacao + " - " + cidade);
    }
    public static Docente criar(){
        var objetoDocente = new Docente();
        var scanner = new Scanner(System.in);

        System.out.println("Nome: ");
        objetoDocente.nome = scanner.nextLine();

        System.out.println("Formação: ");
        objetoDocente.formacao = scanner.nextLine();

        System.out.println("Cidade: ");
        objetoDocente.cidade = scanner.nextLine();

        System.out.println(objetoDocente.nome + "cadastado");
        return objetoDocente;
    }
}
